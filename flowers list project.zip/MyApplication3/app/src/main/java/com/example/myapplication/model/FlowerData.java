package com.example.myapplication.model;


public class FlowerData {

    private String flowerName;
    private int flowerImage;

    public FlowerData(String flowerName, int flowerImage) {
        this.flowerName = flowerName;
        this.flowerImage = flowerImage;
    }

    public String getFlowerName() {
        return flowerName;
    }

    public int getFlowerImage() {
        return flowerImage;
    }
}
