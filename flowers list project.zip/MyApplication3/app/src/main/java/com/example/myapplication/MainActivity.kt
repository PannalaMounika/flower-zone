package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.CustomAdapter
import com.example.myapplication.adapter.MyAdapter
import com.example.myapplication.model.FlowerData
import org.intellij.lang.annotations.JdkConstants.HorizontalAlignment

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // getting the recyclerview by its id
        val recyclerview = findViewById<RecyclerView>(R.id.recycler_view)
        val layoutManager = GridLayoutManager(this, 2)

        recyclerview.layoutManager = layoutManager

        val data = ArrayList<FlowerData>()
data.add(FlowerData("Rose", R.drawable.rose))
        data.add(FlowerData("Carnation",R.drawable.carnation))
        data.add(FlowerData("Tulip",R.drawable.tulip))
        data.add(FlowerData("Daisy",R.drawable.daisy))
        data.add(FlowerData("Sunflower",R.drawable.sunflower))
        data.add(FlowerData("Daffodil",R.drawable.daffodil))
        data.add(FlowerData("Gerbera",R.drawable.gerbera))
        data.add(FlowerData("Orchid",R.drawable.orchid))
        data.add(FlowerData("Iris",R.drawable.lris))
        data.add(FlowerData("Lilac",R.drawable.lilac))

        val adapter = CustomAdapter(data)


        // Setting the Adapter with the recyclerview
        recyclerview.adapter = adapter
    }
}